<?php include 'header.php';?>
<style>
.activeClass {
    background: #0ce166;
}
.nonactiveClass {
    background: #ff1313;
    color: #fff !important;
}
.leaveClass {
    background: #f8aac4;
    color: #fff !important;
}
</style>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper dashbord-main" style="padding-top: 65px;">
        <div class="row">
            <div class="col-md-4 col-5 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Fullcalendar</h4>
                  <div id="datepicker" class="datepicker"></div>
                </div>
                
              </div>
            </div>
            <div class="col-md-8 col-7 grid-margin stretch-card">
              <div class="card "style="padding:50px;">
                <h4 class="card-title">Activity timeline</h4>
                 <div class="  col-md-12 table-responsive" >
                <table class="table table-bordered no-footer  " id="profile">
          <thead>
          <tr class="info">
            
           <th style="text-align:center;">Book Id</th>
            <th style="text-align:center;">Doctor</th>
            <th style="text-align:center;">Specialization </th>
            <th style="text-align:center;">Date AND Time</th>
              <th style="text-align:center;">User Name</th>
               <th style="text-align:center;">Phone Number</th>
                <th style="text-align:center;">Details</th>
                <th style="text-align:center;">Age</th>
            
          </tr>
          </thead>
                 <tbody id="tbldata">
                     
                 </tbody>
                
                

                  
                  <div>
          </table>
          
          
         
                    </div>
                                     </div>
               
              </div>
            </div>
            
          </div>
          </div>

          


        </div>
        <!-- content-wrapper ends -->
       <?php include 'footer.php';?>
<script>

var active_dates =<?php echo json_encode($arr);  ?>;
$("#datepicker").datepicker({
     format: "dd/mm/yyyy",
     autoclose: true,
     todayHighlight: true,
     beforeShowDay: function(date){
         var d = date;
         var curr_date = d.getDate();
         var curr_month = d.getMonth() + 1; //Months are zero based
         var curr_year = d.getFullYear();
         var formattedDate = curr_date + "/" + curr_month + "/" + curr_year

           if ($.inArray(formattedDate, active_dates) != -1){
               return {
                  classes: 'activeClass'
               };
           }
          return;
      }
  }).on('changeDate', function(e){
    var cdate = e.format('yyyy-mm-dd');

var Url  = '<?php echo base_url()?>Booking/getbookingBydate';
      var Data = {cdate:cdate};
      $.ajax({
        method : "post",
        url    :  Url,
        data   :  Data,
         beforeSend:function(){
            $("#tbldata").empty();
 var hg ="<tr ><td colspan='9' >Loading...</td></tr>"
    $("#tbldata").append(hg);
        },
        error:function(xhr){
        },
        success:function(dat){
 $("#tbldata").empty();
var x=JSON.parse(dat);
var dss=x.length;

if(dss==0){
    var hg ="<tr ><td colspan='8' >No data Found</td></tr>";
    $("#tbldata").append(hg);
}else{

     for(i=0;i<=x.length;i++){
var hg ="<tr ><td  >"+x[i].booking_id+"</td><td  >"+x[i].dcname+"</td><td  >"+x[i].spname+"</td><td  >"+x[i].date+" "+x[i].time+"</td><td  >"+x[i].name+"</td><td  >"+x[i].phone_number+"</td><td  >"+x[i].details+"</td><td  >"+x[i].age+"</td></tr>";

$("#tbldata").append(hg);
     }

}


      },  
      });
     });
  </script>