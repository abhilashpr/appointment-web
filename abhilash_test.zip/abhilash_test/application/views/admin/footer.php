 <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021  All rights reserved.</span>
           
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo base_url(); ?>public/admin/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="<?php echo base_url(); ?>public/admin/vendors/chart.js/Chart.min.js"></script>
   <script src="<?php echo base_url(); ?>public/admin/vendors/moment/moment.min.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/vendors/tempusdominus-bootstrap-4/tempusdominus-bootstrap-4.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/vendors/select2/select2.min.js"></script>
    <script src="<?php echo base_url(); ?>public/admin/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.2.7/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.colVis.min.js"></script>

  <script src="<?php echo base_url(); ?>public/admin/vendors/lightgallery/js/lightgallery-all.min.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/vendors/tinymce/tinymce.min.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>


  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo base_url(); ?>public/admin/js/off-canvas.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/js/hoverable-collapse.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/js/template.js"></script>
<script src="<?php echo base_url(); ?>public/admin/js/tooltips.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/js/popover.js"></script>
     <script src="<?php echo base_url(); ?>public/admin/vendors/dropify/dropify.min.js"></script>
     <script src="<?php echo base_url(); ?>public/admin/js/dropify.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/js/dropzone.js"></script>
  <script src="<?php echo base_url(); ?>public/admin/js/jquery-file-upload.js"></script>
    <script src="<?php echo base_url(); ?>public/admin/js/select2.js"></script>
      <script src="<?php echo base_url(); ?>public/admin/js/light-gallery.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url(); ?>public/admin/js/dashboard.js"></script>

</body>

</html>

