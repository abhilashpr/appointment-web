<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title> Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/fullcalendar/fullcalendar.min.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/select2/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
     <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.dataTables.min.css">
      <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.7/css/responsive.dataTables.min.css">
      
  
  <!-- End plugin css for this page -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/dropify/dropify.min.css">
  <!-- inject:css -->
    <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/lightgallery/css/lightgallery.css">
  <!--  plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/vertical-layout-light/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/tempusdominus-bootstrap-4/tempusdominus-bootstrap-4.min.css">
      <link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
  <!-- endinject -->
</head>
<body class="">
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row" >
      <div class="navbar-menu-wrapper d-flex align-items-stretch justify-content-between">
        <ul class="navbar-nav mr-lg-2 d-none d-lg-flex">
          <li class="nav-item nav-toggler-item">
            <button class="navbar-toggler align-self-center" type="button" data-toggle="minimize">
              <span class="mdi mdi-menu"></span>
            </button>
          </li>
         
        </ul>
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="<?php echo base_url(); ?>admin/Dashboard">Logo</a>
        </div>
        <ul class="navbar-nav navbar-nav-right">
          
         
         <li class="nav-item nav-toggler-item-right d-lg-none">
            <button class="navbar-toggler align-self-center" type="button" data-toggle="offcanvas">
              <span class="mdi mdi-menu"></span>
            </button>
          </li>
         
        </ul>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
    
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar" style="padding-top: 28px !important;">
        <ul class="nav">
       <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>admin/AllBookings">
              <i class="mdi mdi-view-quilt menu-icon"></i>
              <span class="menu-title">Booking</span>
            </a>
          </li>
              <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>admin/Dashboard">
              <i class="mdi mdi-view-quilt menu-icon"></i>
              <span class="menu-title">Calender View</span> 
            </a>
          </li>
       
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>admin/signout">
              <i class="mdi mdi-view-quilt menu-icon"></i>
              <span class="menu-title">Signout</span> 
            </a>
          </li>
        
       
      
        </ul>
      </nav>