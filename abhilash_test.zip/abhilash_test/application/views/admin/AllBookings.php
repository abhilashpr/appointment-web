<?php include 'header.php';?>


<script src="<?php echo base_url()?>public/js/dataTables.bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">

          <div class="row">


            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <h4 class="text-center mb-3 ">Booking  List</h4>
                    
                   <div class="row">
				<div class="form-group  col-md-12">
						<form action="" method="get">
						<div class="col-md-6"></div>
						<div class="col-md-6">
						
						
					<div class="form-group">
                   
                      
                    
                   
                  </div>
					</div>
					</form>
				</div>
				
              			<div class="  col-md-12 table-responsive" >
				<table class="table table-bordered no-footer  " id="profile">
          <thead>
          <tr class="info">
            <th style="text-align:center;">Sl.No</th>
           <th style="text-align:center;">Book Id</th>
            <th style="text-align:center;">Doctor</th>
            <th style="text-align:center;">Specialization </th>
            <th style="text-align:center;">Date AND Time</th>
              <th style="text-align:center;">User Name</th>
               <th style="text-align:center;">Phone Number</th>
                <th style="text-align:center;">Details</th>
                <th style="text-align:center;">Age</th>
			
          </tr>
          </thead>
                  <?php $i=0;
				  if(!empty($view))
				  {
                  foreach($view as $row){?>
                  <tr>
                      <td style="text-align:center;"><?php echo $i+1?></td>
                    
					  <td style="text-align:center;"><?php echo $row->booking_id;?></td>
                      <td style="text-align:center;"><?php echo $row->doctor_id;?></td>
                      <td style="text-align:center;"><?php echo $row->sp_id;?></td>
                      <td style="text-align:center;"><?php echo $row->date." ".$row->time;?></td>
                    <td style="text-align:center;"><?php echo $row->name;?></td>
                   <td style="text-align:center;"><?php echo $row->phone_number;?></td>
                        <td style="text-align:center;"><?php echo $row->details;?></td>
                             <td style="text-align:center;"><?php echo $row->age;?></td>
					 </tr>
              <?php   $i++;
                   }
				  }
				  else
				  {?>
					 <tr>
<td colspan ="6" align="center" >No Data</td>
</tr> 
				  <?php }?> 

                  
                  <div>
          </table>
		  
		  
		 
                    </div>
					
                
                </div>
              </div>
            </div>
            
        
            
        
          </div>
        </div>
<script>


 function searchtb(inputVal)
 {
 var table = $('#profile');
   table.find('tr').each(function(index, row)
   {
     var allCells = $(row).find('td');
     if(allCells.length > 0)
     {
       var found = false;
       allCells.each(function(index, td)
       {
         var regExp = new RegExp(inputVal, 'i');
         if(regExp.test($(td).text()))
         {
           found = true;
           return false;
         }
       });
       if(found == true)$(row).show();else $(row).hide();
     }
   });
   
 }
 



</script>
  <script>
 $('#flash_div').fadeIn('slow').delay(2000).fadeOut('slow');
      $(".sidebar-menu").removeClass("active");
     $("#activeempe").addClass("active");
     
     $("#emprege").removeClass("fa fa-angle-left pull-right");
     $("#emprege").addClass("fa fa-angle-down pull-right");
     $("ul #regempe").css("display","block");
     $("#regempe li").removeClass("active");
     $("#employsub2e").addClass("active"); 

           $(document).ready(function() {

    
} );


</script>

</div>

  
<script type="text/javascript">
$(document).ready(function(){
  $("#retaireddate").datepicker({
        format:"dd/mm/yyyy",
        "setDate":new Date(),
         startDate:"01/01/1980" 
      });
 });
</script>



<?php include 'footer.php';?>