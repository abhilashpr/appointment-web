<style>
body {
  font-family: Verdana, Geneva, sans-serif;
  font-size: 14px;
  background: #f2f2f2;
}

.clearfix:after {
  content: "";
  display: block;
  clear: both;
  visibility: hidden;
  height: 0;
}

.form_wrapper {
  background: #fff;
  width: 50%;
  max-width: 100%;
  box-sizing: border-box;
  padding: 25px;
  margin: auto;
  position: relative;
  z-index: 1;
  border-top: 5px solid #f5ba1a;
  -webkit-box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
  -moz-box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
  box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
  -webkit-transform-origin: 50% 0%;
  transform-origin: 50% 0%;
  
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);

}
.form_wrapper h2 {
  font-size: 1.5em;
  line-height: 1.5em;
  margin: 0;
}

</style>

<div class="form_wrapper">
  <div class="form_container">
    <div class="title_container">
      
    </div>
    <div class="row clearfix">
      <div style="text-align: center;">
	  <h2>Booking Completed Successfully !!</h2>
        <a href="<?php echo base_url(); ?>">Book Again</a>
      </div>
    </div>
  </div>
</div>
