<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends CI_Controller {
function __construct() {
        parent::__construct();
          $this->load->model("model_login","",TRUE);
          $this->load->library('form_validation');
          $this->user=$this->session->get_userdata("self_pro_loggedin");
		 

    }


public function selectdoctorlist(){
  $id=$this->input->post('id');
$arr=$this->model_login->getdoctors($id);

 echo json_encode($arr); 
}


public function getbookingBydate(){
 
  $cdate=$this->input->post('cdate');
$arr=$this->model_login->getbookingBydate($cdate);

 echo json_encode($arr); 
}

public function checkbookingtime(){
  $doctor=$this->input->post('doctor');
  $spec=$this->input->post('spec');
  $cdate=$this->input->post('cdate');
   $ctime=$this->input->post('ctime');
$arr=$this->model_login->checkbookingtime($doctor,$spec,$cdate,$ctime);

 echo json_encode($arr); 
}





public function checkbooking(){
  $doctor=$this->input->post('doctor');
  $spec=$this->input->post('spec');
  $cdate=$this->input->post('cdate');
$arr=$this->model_login->checkbooking($doctor,$spec,$cdate);

 echo json_encode($arr); 
}

public function success(){
  $this->load->view('success');
}

public function add(){
if($_POST){
$name=$this->input->post('name');
  $phone=$this->input->post('phone');
  $age=$this->input->post('age');
   $details=$this->input->post('details');
    $spec=$this->input->post('spec');
     $doctor=$this->input->post('doctor');
      $cdate=$this->input->post('cdate');
      $ctime=$this->input->post('ctime');
      $ttime=$this->input->post('ttime');

$data=array(
"doctor_id"=>$doctor,
"sp_id"=>$spec,
"date"=>$cdate,
"time"=>$ctime,
"name"=>$name,
"phone_number"=>$phone,
"details"=>$details,
"status"=>0,
"age"=>$age,
"booking_id"=>rand(111,99999),
"time_to"=>$ttime,
);
$return1=$this->model_login->addbooking($data);
if($return1){
redirect("success");

}else{
  echo "Oops Something Wrong";
}

}else{
  echo "Something Wrong";
} 

}




    } ?>