<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct() {
        parent::__construct();
          $this->load->model("model_login","",TRUE);
          $this->load->library('form_validation');
          $this->user=$this->session->get_userdata("self_pro_loggedin");
		 

    }

	public function index()
	{
		 $data['specialisations']=$this->model_login->getspecializations();

		$this->load->view('booking',$data);

	}
}
