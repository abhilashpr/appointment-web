<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
function __construct() {
        parent::__construct();
          $this->load->model("model_login","",TRUE);
          $this->load->library('form_validation');
          $this->user=$this->session->get_userdata("self_pro_loggedin");
		 

    }
	
	public function index()
	{
		if (!empty($this->user['self_pro_loggedin'])) {
   $dat=$this->model_login->allbookings();
   $ss=array();
if(!empty($dat)){
foreach($dat as $res){
	$date=$res->date;
 $month= date("m",strtotime($date));
$fntdat=date("d",strtotime($date))."/".(int)$month."/".date("Y",strtotime($date));
array_push($ss, $fntdat);
}

$data['arr']=$ss;

}
			$this->load->view('admin/index',$data);

}else{
	redirect("admin");
}

	}
}
