<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model("model_login","",TRUE);
        $this->user=$this->session->get_userdata("self_pro_loggedin");
		$this->load->helper('cookie');
    }

	public function index()
	{
		if($_POST){
					if (empty($this->user['self_pro_loggedin'])) {
 			$a=$this->input->post('username');
           $b=$this->input->post('password');
           $return1=$this->model_login->Loginuser($a,$b);
if($return1)
              {
              	 $session_array =array();
                 $session_array =array('id'=>$return1[0]->id,
                                       'name'=>$return1[0]->username,
                                      );
                 $this->session->set_userdata('self_pro_loggedin',$session_array);
                 redirect("admin/Dashboard");

              	 }
              else
              {
                echo  $error ="Invalid Username and Password";
                // $this->index($error);
              }
}else{
	redirect("admin");
}



		}else{
			redirect("admin");
		}
	}

	 public function signout(){
               
        $this->session->unset_userdata('self_pro_loggedin');
       
      redirect('admin');
  }
}
