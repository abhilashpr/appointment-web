<?php
class Model_login extends CI_Model{

public function addbooking($data){
 $this->db->insert("bookings",$data);
         return $this->db->insert_id();
}

public function getbookingBydate($id){
            $this->db->select('bookings.*,doctors.name as dcname,specialisation.title as spname');
         $this->db->from('bookings');
         $this->db->join('doctors','doctors.id=bookings.doctor_id','left');
         $this->db->join('specialisation','specialisation.id=bookings.sp_id','left');
          $this->db->where("bookings.date" ,$id);
         $query = $this->db->get();
         return  $query->result();
          }

 public  function Loginuser($a,$b) {
         $this->db->select('*');
         $this->db->from('admin_tbl');
         $this->db->where("username" ,$a);
         $this->db->where("password" ,$b);
         $query = $this->db->get();
         if($query->num_rows()==1)
              return  $query->result();
            else
              return 0;
          }

          public function getspecializations(){
            $this->db->select('*');
         $this->db->from('specialisation');
         $query = $this->db->get();
         return  $query->result();
          }
 public function getdoctors($id){
            $this->db->select('*');
         $this->db->from('doctors');
          $this->db->where("specialized_in" ,$id);
         $query = $this->db->get();
         return  $query->result();
          }

public function checkbooking($doctor,$spec,$cdate){
     $this->db->select('*');
         $this->db->from('bookings');
          $this->db->where("doctor_id" ,$doctor);
            $this->db->where("sp_id" ,$spec);
              $this->db->where("date" ,$cdate);
         $query = $this->db->get();
         $return = $query->result();
if(!empty($return)){
return 0;
}else{
    return 1;
}

}

public function checkbookingtime($doctor,$spec,$cdate,$ctime){
     $this->db->select('*');
         $this->db->from('bookings');
          $this->db->where("doctor_id" ,$doctor);
            $this->db->where("sp_id" ,$spec);
              $this->db->where("date" ,$cdate);
                
         $query = $this->db->get();
         $return = $query->result();
         //echo $this->db->last_query();
if(!empty($return)){
if(strtotime($ctime)<=strtotime($return[0]->time_to)&&strtotime($ctime)>=strtotime($return[0]->time)){
 return 0;
}else{
    return 1;
}

}else{
    return 1;
}

}



public function allbookings(){
     $this->db->select('*');
         $this->db->from('bookings');
          
         $query = $this->db->get();
         return  $query->result();


}


}
?>